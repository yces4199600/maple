(1)INT+12%:int.jpg
(2)STR+12%:str.jpg
(3)DEX+12%:dex.jpg
(4)LUK+12%:luk.jpg
(5)全屬+9%:all.jpg
(6)掉寶++ :treasure.jpg
(7)掉幣++ :gold.jpg
